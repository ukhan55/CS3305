#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_PROCESSES 100

typedef struct {
    char process_id[10];
    int burst_time;
    int arrival_time;
    int wait_time;
    int turnaround_time;
} Process;

void fcfs(Process processes[], int num_processes) {
    int current_time = 0;
    int i, j;

    printf("First Come First Serve\n");
    int time = 0; 
    for (i = 0; i < num_processes; i++) {
        // Calculate wait time and turnaround time for each process
        processes[i].wait_time = current_time - processes[i].arrival_time;
        processes[i].turnaround_time = processes[i].wait_time;
        while(processes[i].burst_time > 0){
            if (processes[i].wait_time < 0) {
                processes[i].wait_time = 0;
            }
             
            // Print process info
            printf("T%d : %s - Burst Left %d, Wait time %d, Turnaround Time %d \n", time,processes[i].process_id,processes[i].burst_time, processes[i].wait_time , processes[i].turnaround_time);
            time++;
            // Update current time
            current_time += 1;
            processes[i].turnaround_time += 1;
            processes[i].burst_time--;
        }
        
    }
    printf("\n\n");

    for(int i = 0; i < num_processes; i++){
        printf("%s\n",processes[i].process_id);
        printf("\tWaiting Time: %d\n", processes[i].wait_time);
        printf("\tTurnaround Time: %d\n", processes[i].turnaround_time);
        printf("\n\n");
    }
    // Calculate average wait time and turnaround time
    float avg_wait_time = 0, avg_turnaround_time = 0;
    for (i = 0; i < num_processes; i++) {
        avg_wait_time += processes[i].wait_time;
        avg_turnaround_time += processes[i].turnaround_time;

    }
    avg_wait_time /= num_processes;
    avg_turnaround_time /= num_processes;

    // Print summary info
    printf("Average Wait Time: %.1f\n", avg_wait_time);
    printf("Average Turnaround Time: %.1f\n", avg_turnaround_time);
}

void sjf(Process processes[], int n) {
    
    int current_time = 0;
    int completed_processes = 0;

    while (completed_processes != n) {
        // Find the process with shortest remaining time
        int shortest_index = -1;
        int shortest_time = 1000000;
        for (int i = 0; i < n; i++) {
            if (processes[i].burst_time > 0 && processes[i].burst_time < shortest_time && processes[i].arrival_time <= current_time) {
                shortest_index = i;
                shortest_time = processes[i].burst_time;
            }
        }

        if (shortest_index == -1) {
            current_time++;
            continue;
        }

        // Update waiting time and turnaround time for the current process
        
        processes[shortest_index].turnaround_time = current_time + processes[shortest_index].burst_time - processes[shortest_index].arrival_time;
        processes[shortest_index].wait_time = current_time - processes[shortest_index].arrival_time;
        if(processes[shortest_index].wait_time < 0)
            processes[shortest_index].wait_time =0;
        printf("T%d : %s - Burst Left %d, Wait time %d, Turnaround Time %d\n", current_time, processes[shortest_index].process_id , processes[shortest_index].burst_time, processes[shortest_index].wait_time, processes[shortest_index].turnaround_time);

        // Run the process for 1 time unit
        processes[shortest_index].burst_time--;
        current_time++;

        // If the process has finished
        if (processes[shortest_index].burst_time == 0) {
            completed_processes++;
        }
    }
    
    printf("\n\n");
    for(int i = 0; i < n; i++){
        printf("%s\n",processes[i].process_id);
        printf("\tWaiting Time: %d\n", processes[i].wait_time);
        printf("\tTurnaround Time: %d\n", processes[i].turnaround_time);
        printf("\n\n");
    }
    // Calculate average wait time and turnaround time
    float avg_wait_time = 0, avg_turnaround_time = 0;
    for (int i = 0; i < n; i++) {
        avg_wait_time += processes[i].wait_time;
        avg_turnaround_time += processes[i].turnaround_time;

    }
    avg_wait_time /= n;
    avg_turnaround_time /= n;

    // Print summary info
    printf("Average Wait Time: %.1f\n", avg_wait_time);
    printf("Average Turnaround Time: %.1f\n", avg_turnaround_time);

}

void round_robin(Process processes[], int n, int quantum) {
    int current_time = 0;
    int completed_processes = 0;

    printf("Round Robin with Quantum %d\n", quantum);
    
    while (completed_processes != n) {
        // Process all the processes in a round-robin fashion
        for (int i = 0; i < n; i++) {
            if (processes[i].burst_time > 0 && current_time >= i) {
                // Run the process for the given quantum or until it finishes
                int quantum_count = 0;
                while(quantum_count < quantum && processes[i].burst_time != 0){
                    // Display information about the process
                    printf("T%d : P%d - Burst Left %d, Wait time %d, Turnaround Time %d\n", current_time, i, processes[i].burst_time, processes[i].wait_time, processes[i].turnaround_time);
                    // Update waiting and turnaround times for the completed process
                    processes[i].turnaround_time = current_time - processes[i].arrival_time;
                    processes[i].wait_time = processes[i].turnaround_time - processes[i].burst_time;
                    if(processes[i].wait_time < 0){
                        processes[i].wait_time = 0;
                    }
                    processes[i].burst_time -= 1;            
                    current_time += 1;
                    quantum_count++;
                }
                
                // If the process has finished
                if (processes[i].burst_time == 0) {
                    completed_processes++;
                }
            }
        }
    }

    // Display the waiting and turnaround times for each process
    for (int i = 0; i < n; i++) {
        printf("\n");
        printf("P%d:\n", i);
        printf("\tWaiting Time: %d\n", processes[i].wait_time);
        printf("\tTurnaround Time: %d\n", processes[i].turnaround_time);
    }
    
    // Calculate average wait time and turnaround time
    float avg_wait_time = 0, avg_turnaround_time = 0;
    for (int i = 0; i < n; i++) {
        avg_wait_time += processes[i].wait_time;
        avg_turnaround_time += processes[i].turnaround_time;

    }
    avg_wait_time /= n;
    avg_turnaround_time /= n;

    // Print summary info
    printf("Average Wait Time: %.1f\n", avg_wait_time);
    printf("Average Turnaround Time: %.1f\n", avg_turnaround_time);
}



int main(int argc, char *argv[]) {
    bool fcfs_ = false;
    bool sjf_ = false;
    bool rr_ = false;
    int quantum = 0;
    char* filename = NULL;
    int num_processes = 0;
    Process processes[MAX_PROCESSES];
    if(argc < 3 || argc > 4){
        printf("Invalid Parameters");
        printf("Proper Usage is ./assign,emt-4 [-f/-s/-r <quantum>] <input file name>");
        return 0;
    }

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-f") == 0) {
            fcfs_ = true;
            filename = argv[i+1];
        } else if (strcmp(argv[i], "-s") == 0) {
            sjf_ = true;
            filename = argv[i+1];
        } else if (strcmp(argv[i], "-r") == 0) {
            if(argc != 4){
                printf("Invalid Parameters");
                printf("Proper Usage is ./assign,emt-4 [-f/-s/-r <quantum>] <input file name>");
                return 0;
            }
            rr_ = true;
            quantum = atoi(argv[i+1]);
            filename = argv[i+2];

        }
    }

    // Open the input file
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Could not open file %s \n",filename);
        return 1;
    }

    // Read in the processes from the file
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char* name = strtok(line, ",");
        char* burst_str = strtok(NULL, ",");
        int burst_time = atoi(burst_str);
        processes[num_processes].arrival_time = num_processes;
        strcpy(processes[num_processes].process_id, name);
        processes[num_processes].burst_time = burst_time;
        processes[num_processes].wait_time = 0;
        processes[num_processes].turnaround_time = 0;
        num_processes++;
    }

    // Close the file
    fclose(file);

    // Run the scheduling algorithm
    if (fcfs_) {
        fcfs(processes, num_processes);
    } else if (sjf_) {
        // Implement Shortest Job First scheduling
        sjf(processes, num_processes);
    } else if (rr_) {
        // Implement Round Robin scheduling
        // ...
        round_robin(processes, num_processes,quantum);
    } else {
        fprintf(stderr, "Error: no scheduling algorithm specified\n");
        return 1;
    }

    return 0;
}

