#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

// Constants
#define NUM_STATIONS 5
#define NUM_TRAINS 2
#define TRAIN_0_CAPACITY 250
#define TRAIN_1_CAPACITY 200

// Global variables
int stations[NUM_STATIONS] = {500, -50, -100, -250, -100};
pthread_mutex_t mutex_stations[NUM_STATIONS];
sem_t sem_stations[NUM_STATIONS];

// Function prototypes
void *train_thread(void *train_id);
int pick_up_passengers(int station_id, int capacity);
int drop_off_passengers(int station_id, int capacity);

int main() {
    pthread_t trains[NUM_TRAINS];

    // Initialize mutexes and semaphores
    for (int i = 0; i < NUM_STATIONS; i++) {
        pthread_mutex_init(&mutex_stations[i], NULL);
        sem_init(&sem_stations[i], 0, 1);
    }

    // Create train threads
    for (int i = 0; i < NUM_TRAINS; i++) {
        pthread_create(&trains[i], NULL, train_thread, (void *)(intptr_t)i);
    }

    // Wait for train threads to finish
    for (int i = 0; i < NUM_TRAINS; i++) {
        pthread_join(trains[i], NULL);
    }

    // Print status
    printf("----------------------------\n");
    for (int i = 0; i < NUM_STATIONS; i++) {
        printf("Station %d has %d passengers\n", i, stations[i]);
    }

    // Cleanup
    for (int i = 0; i < NUM_STATIONS; i++) {
        pthread_mutex_destroy(&mutex_stations[i]);
        sem_destroy(&sem_stations[i]);
    }

    return 0;
}

int pick_up_passengers(int station_id, int capacity) {
    int passengers_to_pick_up = (stations[station_id] < capacity) ? stations[station_id] : capacity;
    stations[station_id] -= passengers_to_pick_up;

    return passengers_to_pick_up;
}

int drop_off_passengers(int station_id, int passengers_on_train) {
    int passengers_to_drop_off = (passengers_on_train < -stations[station_id]) ? passengers_on_train : -stations[station_id];
    stations[station_id] += passengers_to_drop_off;

    return passengers_to_drop_off;
}


void *train_thread(void *train_id) {
    int id = (intptr_t)train_id;
    int capacity = (id == 0) ? TRAIN_0_CAPACITY : TRAIN_1_CAPACITY;
    int passengers_on_train = 0;

    int station_id = 0;
    while (1) {
        sem_wait(&sem_stations[station_id]);
        pthread_mutex_lock(&mutex_stations[station_id]);

        if (station_id == 0) {
            printf("Train %d ENTERS Station %d\n", id, station_id);
            printf("Station %d has %d passengers to pick up\n", station_id, stations[station_id]);
            passengers_on_train += pick_up_passengers(station_id, capacity - passengers_on_train);
            printf("Picking up passengers...\n");
                            int sleep_time = (passengers_on_train / 100) * 10; // 10 seconds for every 100 passengers
    sleep(sleep_time); 
            printf("Train %d is at Station %d and has %d/%d passengers\n", id, station_id, passengers_on_train, capacity);
            printf("Station %d has %d passengers left to pick up\n", station_id, stations[station_id]);  
     
            } else {
            printf("Train %d ENTERS Station %d\n", id, station_id);
            printf("Station %d has %d passengers to drop off\n", station_id, -stations[station_id]);
            passengers_on_train -= drop_off_passengers(station_id, passengers_on_train);
            printf("Dropping off passengers...\n");
                            int sleep_time = (abs(passengers_on_train) / 100) * 10; // 10 seconds for every 100 passengers
    sleep(sleep_time);
            printf("Train %d is at Station %d and has %d/%d passengers\n", id, station_id, passengers_on_train, capacity);
            printf("Station %d has %d passengers left to drop off\n", station_id, -stations[station_id]);



        }
            if (station_id == 0 || stations[station_id] <= 0) {
                printf("Train %d LEAVES Station %d\n", id, station_id);
                station_id++;
                if (station_id >= NUM_STATIONS) {
                    station_id = 0;
                }
            }
        pthread_mutex_unlock(&mutex_stations[station_id]);
        sem_post(&sem_stations[station_id]);

        // Add some sleep time to allow for better visualization of the output
        sleep(1);

        // Break the loop when there are no more passengers to pick up or drop off
        int done = 1;
        for (int i = 0; i < NUM_STATIONS; i++) {
            if (stations[i] != 0) {
                done = 0;
                break;
            }
        }

        if (done) {
            break;
        }
    }

    return NULL;
}
